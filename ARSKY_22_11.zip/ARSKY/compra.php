<?php
session_start();
$servername = "127.0.0.1";
$username = "alumno"; // Cambia esto si usas otro usuario
$password = "alumnoipm"; // Asegúrate de usar la contraseña correcta
$database = "arsky";
$port = 3306;

$conexion = mysqli_connect($servername, $username, $password, $database, $port);
// Verificar la conexión
if (!$conexion) {
    die("Conexión fallida: " . mysqli_connect_error());
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $cantCuotas = $_POST['cant_cuotas'];
    $metodoPago = mysqli_real_escape_string($conexion, $_POST['metodo-pago']);
    $tarjeta = mysqli_real_escape_string($conexion, $_POST['numero']);
    $asiento = mysqli_real_escape_string($conexion, $_POST['asiento']);
    $dni = mysqli_real_escape_string($conexion, $_SESSION['DNI']);
    $vueloId = $_POST['id'];

    // Verificar si la tarjeta existe
    $result = mysqli_query($conexion, "SELECT * FROM tarjeta WHERE Numero='$tarjeta'");
    if (mysqli_num_rows($result) > 0) {
        // Si la tarjeta existe, procede con la actualización
        mysqli_query($conexion, "UPDATE tarjeta SET cliente_DNI='$dni' WHERE Numero='$tarjeta' and Tipo='2'");
    } else {
        echo "Error: La tarjeta con el número $tarjeta no existe.";
        exit;
    }
    // Verificar si el asiento ya está ocupado para este vuelo
$asiento_check_query = "SELECT Asiento_ID FROM boleto WHERE vuelo_ID='$vueloId' AND Asiento_ID='$asiento' LIMIT 1";
$asiento_check = mysqli_query($conexion, $asiento_check_query);

if (mysqli_num_rows($asiento_check) > 0) {
    // Si se encuentra un asiento que coincide, significa que ya está ocupado
    ?>
                <!DOCTYPE html>
                <html lang="en">
                <head>
                    <meta charset="UTF-8">
                    <meta name="viewport" content="width=device-width, initial-scale=1.0">
                    <link href="compra.css" rel="stylesheet">
                    <title>Document</title>
                </head>
                <body>
                <main>
                <div id="div_borde_login">
                    <div id="div_fondo_login">
                        <h1>Error</h1>
                        <p>El asiento <?php $asiento ?> está ocupado</p>
                        <p>Haga click <a href="index.php">aqui</a> para volver al inicio</p>
                    </div>
                </div>
            </main><?php
    exit;
}

    // Inserta la compra en la base de datos
    $sql_compra = "INSERT INTO compra (Cantidad_Cuotas, fecha, cliente_ID, Tarjeta) VALUES ($cantCuotas, CURRENT_DATE(), $dni, '$tarjeta')";
    if (mysqli_query($conexion, $sql_compra)) {
        $compra_id = mysqli_insert_id($conexion);

        $sql_precio = "SELECT precio FROM clase JOIN asiento ON Asiento_Clase=clase.ID WHERE asiento.ID='$asiento'";
        $resultado_precio = mysqli_query($conexion, $sql_precio);

        if ($resultado_precio && mysqli_num_rows($resultado_precio) > 0) {
            $fila_precio = mysqli_fetch_assoc($resultado_precio);
            $precio = $fila_precio['precio'];

            // Inserta el boleto
            $sql_boleto = "INSERT INTO boleto (precio, vuelo_id, compra_id, asiento_id) VALUES ('$precio', '$vueloId', '$compra_id', '$asiento')";
            if (mysqli_query($conexion, $sql_boleto)) {
                ?>
                <!DOCTYPE html>
                <html lang="en">
                <head>
                    <meta charset="UTF-8">
                    <meta name="viewport" content="width=device-width, initial-scale=1.0">
                    <link href="compra.css" rel="stylesheet">
                    <title>Document</title>
                </head>
                <body>
                <main>
                <div id="div_borde_login">
                    <div id="div_fondo_login">
                        <h1>compra Exitosa</h1>
                        <p>Código de compra: <?php $compra_id ?></p>
                        <p>Haga click <a href="index.php">aqui</a> para volver al inicio</p>
                    </div>
                </div>
            </main><?php
            } else {
                ?>
                <!DOCTYPE html>
                <html lang="en">
                <head>
                    <meta charset="UTF-8">
                    <meta name="viewport" content="width=device-width, initial-scale=1.0">
                    <link href="compra.css" rel="stylesheet">
                    <title>Document</title>
                </head>
                <body>
                <main>
                <div id="div_borde_login">
                    <div id="div_fondo_login">
                        <h1>Error</h1>
                        <p>Error al insertar el boleto</p>
                        <p>Haga click <a href="index.php">aqui</a> para volver al inicio</p>
                    </div>
                </div>
            </main><?php
            }
        } else {
            ?>
                <!DOCTYPE html>
                <html lang="en">
                <head>
                    <meta charset="UTF-8">
                    <meta name="viewport" content="width=device-width, initial-scale=1.0">
                    <link href="compra.css" rel="stylesheet">
                    <title>Document</title>
                </head>
                <body>
                <main>
                <div id="div_borde_login">
                    <div id="div_fondo_login">
                        <h1>Error</h1>
                        <p>Error al obtener precio del asiento</p>
                        <p>Haga click <a href="index.php">aqui</a> para volver al inicio</p>
                    </div>
                </div>
            </main><?php
        }
    } else {
        ?>
                <!DOCTYPE html>
                <html lang="en">
                <head>
                    <meta charset="UTF-8">
                    <meta name="viewport" content="width=device-width, initial-scale=1.0">
                    <link href="compra.css" rel="stylesheet">
                    <title>Document</title>
                </head>
                <body>
                <main>
                <div id="div_borde_login">
                    <div id="div_fondo_login">
                        <h1>Error</h1>
                        <p>Error al realizar la compra</p>
                        <p>Haga click <a href="index.php">aqui</a> para volver al inicio</p>
                    </div>
                </div>
            </main><?php
    }
}

mysqli_close($conexion);

?>
</body>
</html>