#include <fstream>
#include <iostream>
#include <sstream>  // Para usar stringstream
#include <string>

using namespace std;

int main() {
    ifstream archivo;
    archivo.open("../nombres.txt", ios::in);

    if (archivo.is_open()) {
        string nombre = "";
        string pass = "";
        string linea;  // Línea para leer cada entrada en el archivo

        cout << "Ingrese el nombre que desea buscar: ";
        cin >> nombre;
        cout << "Contraseña: ";
        cin >> pass;

        bool encontrado = false;  // Bandera para saber si encontramos el usuario
        while (getline(archivo, linea)) {  // Leemos línea por línea
            string nombreaux, passaux;

            // Usamos un stringstream para separar el nombre y la contraseña
            stringstream ss(linea);
            getline(ss, nombreaux, ';');  // Obtener nombre hasta el ';'
            getline(ss, passaux, ';');   // Obtener contraseña hasta el '!'
            
            cout << "Comparando: '" << nombreaux << "' == '" << nombre << "'\n";
            if (nombreaux == nombre) {
                // Si el nombre es correcto, comparamos la contraseña
                if (passaux == pass) {
                    cout << "¡Login correcto!" << endl;
                    encontrado = true;
                    break;
                } else {
                    cout << "Contraseña incorrecta." << endl;
                    break;
                }
            }
        }

        if (!encontrado) {
            cout << "Nombre de usuario no encontrado." << endl;
        }

        archivo.close();  // No olvides cerrar el archivo después de usarlo
    } else {
        cout << "No se pudo abrir el archivo." << endl;
    }

    return 0;
}
