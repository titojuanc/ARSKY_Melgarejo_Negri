#include <fstream>
#include <iostream>
using namespace std;

int main(){
    ofstream archivo;
    archivo.open("../nombres.txt", ios::app);

    if(archivo.is_open()){
        string nombre = "";
        for (int i = 0; i < 10; i++)
        {
            cout<<"Ingrese el nombre "<<i+1<<": "<<endl;
            cin>>nombre;
            archivo << nombre << ';' << nombre << '.' << endl;
        }
    archivo.close();        
    }
}