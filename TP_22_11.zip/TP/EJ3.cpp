#include <fstream>
#include <iostream>
using namespace std;

int main(){
    ofstream archivo;
    archivo.open("../nombres.txt", ios::out);
}