#include <fstream>
#include <iostream>
using namespace std;

int main(){
    ifstream archivo;
    archivo.open("../nombres.txt", ios::in);

    if(archivo.is_open()){
        string nombre = "";
        string aux;
        string pass;
        cout<<"Ingrese el nombre que desea buscar: "<<endl;
        cin>>nombre;
        cout<<"Contraseña: "<<endl;
        cin>>pass;
        while(getline(archivo, aux, '!')){
            string nombreaux="";
            string passaux="";
            int pointer;
            for (int i = 0; aux[i] != ';' ; i++){
                cout<<"entré"<<endl;
                nombreaux=nombreaux+aux[i];
                cout<<nombreaux<<endl;
                pointer=i;
            }
            cout<<nombreaux<<"=="<<nombre<<endl;
            if (nombreaux==nombre){
                cout<<"nombre correcto"<<endl;
                for(int i=pointer+2 ; aux[i] != ';' ; i++){    
                    cout<<"entré"<<endl;
                    passaux=passaux+aux[i];
                }
                if(passaux==pass){
                   cout<<"logueado correctamente"<<endl;
                   break; 
                }
                else{
                    cout<<"contraseña incorrecta"<<endl;
                }        
            }
            else{
                cout<<"nombre incorrecto";
            }       
    }
}
}